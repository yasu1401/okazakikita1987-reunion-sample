"""End-to-end tests against an isolated local PHP process and disposable database."""
import zlib, struct, json, datetime
import os, sys, tempfile, subprocess, time, urllib.request, urllib.parse, urllib.error, http.cookiejar, re, pathlib, sqlite3
root=pathlib.Path(__file__).resolve().parents[1]
php=sys.argv[1] if len(sys.argv)>1 else 'php'
with tempfile.TemporaryDirectory(prefix='kita-http-') as tmp:
    env=dict(os.environ,REUNION_TEST_DSN='sqlite:'+tmp+'/test.sqlite',REUNION_TEST_STORAGE=tmp+'/private')
    subprocess.run([php,str(root/'scripts/manage.php'),'seed'],env=env,check=True,capture_output=True)
    with sqlite3.connect(tmp+'/test.sqlite') as setup:
        settings=json.loads(setup.execute('SELECT data_json FROM settings WHERE id=1').fetchone()[0])
        # Keep fixture deadlines open independently of the real event calendar.
        today=datetime.date.today()
        settings.update(open=str(today-datetime.timedelta(days=1)))
        for key in ('registration','payment','change','cancel','photoEnd'):
            settings[key]=str(today+datetime.timedelta(days=365))
        setup.execute('UPDATE settings SET data_json=? WHERE id=1',(json.dumps(settings),))
    srv=subprocess.Popen([php,'-d','session.upload_progress.enabled=0','-S','127.0.0.1:8791','-t',str(root/'public'),str(root/'public/router.php')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    base='http://127.0.0.1:8791/?page='
    n=0
    def check(ok,label):
        global n
        assert ok,label
        n+=1;print('PASS',n,label)
    def client():return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def request(c,page,data=None,files=None,accept_json=False):
        headers={'Accept':'application/json'} if accept_json else {}
        if files:
            boundary='KitaReunionTestBoundary';parts=[]
            for k,v in data.items():parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
            for k,(name,mime,content) in files.items():parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"; filename="{name}"\r\nContent-Type: {mime}\r\n\r\n'.encode()+content+b'\r\n')
            body=b''.join(parts)+f'--{boundary}--\r\n'.encode();headers['Content-Type']='multipart/form-data; boundary='+boundary
        else:body=urllib.parse.urlencode(data).encode() if data is not None else None
        try:
            r=c.open(urllib.request.Request(base+page,data=body,headers=headers));return r.status,r.read()
        except urllib.error.HTTPError as e:return e.code,e.read()
    def token(c,page):
        status,b=request(c,page);m=re.search(rb'name="csrf" value="([a-f0-9]+)"',b);assert m,(status,b[:500]);return m[1].decode()
    def post(c,page,action,values={},files=None,accept_json=False):return request(c,page,{'csrf':token(c,page),'action':action,**values},files,accept_json)
    def login(i):
        c=client();status,b=post(c,'login','login',{'email':f'sample{i}@example.test','password':'111111'});assert status==200,(status,b[:100]);return c
    try:
        for _ in range(50):
            try:request(client(),'home');break
            except urllib.error.URLError:time.sleep(.1)
        anon=client();s,b=request(anon,'home');check(s==200 and b'event-overview' in b and f"{settings['fee']:,}円".encode() in b and b'participation-fee' in b and settings['dateLabel'].encode() in b and b'class-card' in b and 'みんな、集まってきています。'.encode() in b,'未ログインのトップに設定日程・会費・クラス人数')
        check('入金期限'.encode() not in b and 'キャンセル期限'.encode() not in b,'トップに入金・キャンセル期限を表示しない')
        s,b=request(anon,'register');check(s==200 and '入金期限'.encode() in b and '内容変更期限'.encode() in b and 'キャンセル期限'.encode() in b,'申込フォーム内に入金・変更・キャンセル期限を表示')
        s,b=request(anon,'home');check(b'max="47"' in b and '在籍'.encode() not in b and '470'.encode() not in b and '申込締切'.encode() not in b,'トップの基準人数は数字を表示せず棒グラフだけに利用')
        s,b=request(anon,'admin');check(s==403,'未ログインの管理画面は拒否')
        participant=login(3);s,b=request(participant,'my');check('申込番号 003'.encode() in b and '申込番号 001'.encode() not in b,'本人の申込だけを表示')
        s,b=request(participant,'admin_roles');check(s==403,'一般参加者の幹事権限画面を拒否')
        s,b=request(participant,'my',{'action':'cancel','reason':'test','csrf':'forged'});check(s==400,'CSRF不一致の更新を拒否')
        owner=login(1);organizer=login(2)
        for account,label,visible in [(anon,'未ログイン',False),(participant,'参加者',False),(organizer,'幹事',True),(owner,'管理者',True)]:
            for page in ('home','my','register'):
                status,body=request(account,page)
                header=re.search(rb'<header>(.*?)</header>',body,re.S)
                check(status==200 and header is not None and (b'href="?page=admin"' in header[1])==visible,label+'の'+page+'で幹事メニューの権限表示')
        logout_client=login(2)
        s,b=post(logout_client,'home','logout')
        check(s==200 and b'href="?page=admin"' not in re.search(rb'<header>(.*?)</header>',b,re.S)[1],'ログアウト後は幹事メニューを表示しない')
        values={'date':'2026-10-29','category':'印刷費','payee':'架空店','purpose':'資料','amount':'1000','reason':'操作検証'}
        receipt=b'%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\n%%EOF\n'
        s,b=post(organizer,'admin_accounting','expense',values,{'receipt':('sample.pdf','application/pdf',receipt)});check(s==200,'経費と領収書を同時保存')
        con=sqlite3.connect(tmp+'/test.sqlite');eid=con.execute('select max(id) from expenses').fetchone()[0];fid=con.execute('select max(id) from private_files').fetchone()[0]
        s,b=request(participant,'file&id='+str(fid));check(s==403,'領収書のURLを知っていても参加者は取得不可')
        s,b=request(owner,'file&id='+str(fid));check(s==200 and b==receipt,'幹事だけが領収書をダウンロード')
        s,b=post(organizer,'admin_accounting','approve_expense',{'id':eid,'reason':'自己承認試験'});check(s==400,'自分の経費の承認を拒否')
        s,b=post(owner,'admin_accounting','approve_expense',{'id':eid,'reason':'別幹事で確認'});check(s==200,'別の幹事が承認')
        csv='管理情報\n日付,摘要,摘要内容,支払い金額,預かり金額,差引残高,メモ,未資金化区分,入払区分\n20261029,出金,印刷費,1000,,9000,,,出金\n'.encode()
        s,b=post(owner,'admin_bank','import',{}, {'csv':('bank.csv','text/csv',csv)});check(s==200,'ブラウザーと同じmultipartで銀行CSV取込')
        s,b=post(owner,'admin_bank','bank_decide',{'id':1,'state':'confirmed','reason':'原票の確認'});check(s==200,'出金を手動で確認')
        s,b=post(owner,'admin_bank','allocate',{'bank_id':1,'expense_id':eid,'amount':1000,'reason':'領収書と一致'});check(s==200,'出金と経費を照合')
        s,b=post(owner,'admin_bank','allocate',{'bank_id':1,'expense_id':eid,'amount':1,'reason':'二重試験'});check(s==400,'同じ出金の二重割当をHTTPでも拒否')
        s,b=request(owner,'export&kind=finance');check(s==200 and b.startswith(b'\xef\xbb\xbf'),'収支CSV出力')
        def chunk(k,d):return struct.pack('>I',len(d))+k+d+struct.pack('>I',zlib.crc32(k+d)&0xffffffff)
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',2,2,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b'\x00\xff\x00\x00\xff\x00\x00'*2))+chunk(b'IEND',b'')
        s,b=post(owner,'admin_photos','photo',{'class':3},{'photo':('sample.png','image/png',png)});check(s==200,'GDで画像を再エンコードし非公開登録')
        photoid=con.execute("select max(id) from private_files where kind='photo'").fetchone()[0]
        s,b=request(participant,'file&id='+str(photoid));check(s==403,'非公開写真の直接URLを拒否')
        s,b=post(owner,'admin_photos','publish',{'id':photoid,'reason':'見本公開'});check(s==200,'幹事が写真を公開')
        s,b=request(participant,'file&id='+str(photoid));check(s==200 and b.startswith(b'\xff\xd8'),'ログイン参加者が写真をダウンロード')
        s,b=request(anon,'file&id='+str(photoid));check(s==403,'公開写真でも未ログインの直接取得は拒否')
        s,b=post(owner,'admin_photos','publish',{'id':photoid,'reason':'見本取下げ'});check(s==200,'写真公開取り下げ')
        s,b=request(participant,'file&id='+str(photoid));check(s==403,'取り下げ後は同じURLでも拒否')

        s,b=post(owner,'admin_bank','import',{}, {'csv':('shiftjis.csv','text/csv',csv.decode().encode('cp932'))});check(s==200,'Shift-JISの銀行CSVを実際に取込')
        # Public inquiries, protected replies, class contacts and scene albums.
        s,b=request(anon,'home');check(s==200 and b'name="submission"' in b,'未ログインのトップに問い合わせフォーム')
        nonce=re.search(rb'name="submission" value="([a-f0-9]+)"',b)[1].decode()
        inquiry={'class':'0','name':'架空の質問者','email':'reply@example.test','subject':'問い合わせ <script>','body':'秘密の見本本文','submission':nonce}
        s,b=post(anon,'home','contact',inquiry);check(s==200 and '受け付けました'.encode() in b,'未ログインから問い合わせ受付')
        check(con.execute('select class_no from inquiries where id=1').fetchone()[0]==0,'クラスを忘れたの選択をDB保存')
        s,b=request(participant,'admin_inquiries&id=1');check(s==403 and '秘密の見本本文'.encode() not in b,'参加者から問い合わせ管理を拒否')
        s,b=request(owner,'admin_inquiries&id=1');check(s==200 and 'クラスを忘れた'.encode() in b and b'&lt;script&gt;' in b and '秘密の見本本文'.encode() in b,'幹事が本文確認・XSS文字をエスケープ')
        key=re.search(rb'name="reply_key" value="([a-f0-9]+)"',b)[1].decode()
        s,b=post(owner,'admin_inquiries&id=1','inquiry_reply',{'id':1,'body':'架空の回答です','reply_key':key,'to_email':'forged@example.test'})
        check(s==200 and '架空の回答です'.encode() in b,'幹事から返信を保存・履歴表示')
        s,b=request(owner,'admin_mail');check(s==200 and b'reply@example.test' in b and b'forged@example.test' not in b and '開発用・未送信'.encode() in b,'元の返信先へ開発メール記録・外部送信なし')
        s,b=request(participant,'home');nonce=re.search(rb'name="submission" value="([a-f0-9]+)"',b)[1].decode()
        s,b=post(participant,'home','contact',{**inquiry,'submission':nonce});check(s==200 and con.execute('select user_id from inquiries where id=2').fetchone()[0]==3,'ログイン中もトップから問い合わせ可能')
        s,b=post(owner,'admin_contacts&mode=classes&class=3','contact_add',{'class':3,'user_id':3,'position':1,'reason':'見本担当指定'});check(s==200 and '表示指定を解除'.encode() in b,'代表幹事がクラス幹事の表示を指定')
        s,b=request(participant,'my');check('3年3組のクラス幹事'.encode() in b and con.execute('select role from users where id=3').fetchone()[0]=='participant','本人の画面にクラス幹事・管理権限を増やさない')
        s,b=request(anon,'classes&class=3');check(s==200 and b'name-card' in b and b'sample3@example.test' not in b,'名簿は名前カードと人数のみ公開')
        s,b=post(owner,'admin_photos','album_save',{'name':'二次会の思い出','description':'見本','position':4,'visible':'yes','reason':'追加'});check(s==200,'種類別アルバムを追加')
        aid=con.execute('select max(id) from albums').fetchone()[0]
        s,b=post(owner,'admin_photos','photo_move',{'id':photoid,'album_id':aid,'reason':'場面を分類'});check(s==200,'既存写真を別アルバムへ移動')
        post(owner,'admin_photos','publish',{'id':photoid,'reason':'見本再公開'})
        s,b=request(participant,'gallery');check(s==200 and '二次会の思い出'.encode() in b,'参加者は場面ごとのアルバムを閲覧')
        post(owner,'admin_photos','album_save',{'id':aid,'name':'二次会の思い出','description':'見本','position':4,'visible':'no','reason':'非表示'})
        s,b=request(participant,'file&id='+str(photoid));check(s==403,'非表示アルバムの写真を直接URLでも拒否')
        s,b=request(participant,'gallery');check('二次会の思い出'.encode() not in b,'非表示アルバムを参加者の一覧から除外')
        # Participant photo posting, administrator moderation, direct-URL revocation.
        s,b=request(participant,'my');check(s==200 and '写真とコメントを投稿する'.encode() in b,'本人画面に投稿フォーム')
        nonce=re.search(rb'name="post_key" value="([a-f0-9]+)"',b)[1].decode()
        postdata={'title':'最近の風景','caption':'架空コメント <script>alert(1)</script>','author':'見本ニックネーム','consent':'yes','post_key':nonce,'owner_id':1,'album_id':1}
        before=con.execute('select count(*) from private_files').fetchone()[0]
        s,b=request(participant,'my',{'csrf':'forged','action':'post_photo',**postdata},{'photo':('sample.png','image/png',png)});check(s==400 and con.execute('select count(*) from private_files').fetchone()[0]==before,'写真投稿のCSRFを拒否・保存なし')
        s,b=post(participant,'my','post_photo',postdata,{'photo':('sample.png','image/png',png)});check(s==200 and '掲載しました'.encode() in b,'参加者がJPEG/PNGを投稿し自動掲載')
        pfid,ownerid,pa,publication=con.execute('select id,owner_id,album_id,published from private_files where submitted=1 order by id desc limit 1').fetchone()
        submissionalbum=con.execute("select id from albums where purpose='submissions'").fetchone()[0]
        check(ownerid==3 and pa==submissionalbum and publication==1,'投稿者・投稿先・公開状態はサーバー側で固定')
        post(participant,'my','post_photo',postdata,{'photo':('same.png','image/png',png)})
        check(con.execute('select count(*) from private_files where submitted=1').fetchone()[0]==1,'二重送信で写真を重複登録しない')
        s,b=request(participant,'gallery&album='+str(submissionalbum));check(b'&lt;script&gt;' in b and '見本ニックネーム'.encode() in b,'投稿写真・コメント・表示名を表示しXSSを無害化')
        edit={'id':pfid,'title':'幹事修正','caption':'修正したコメント','author':'見本名','album_id':submissionalbum,'sort_order':2,'published':'yes','reason':'内容確認'}
        s,b=post(participant,'my','photo_edit',edit);check(s==400,'参加者による管理者の編集操作を拒否')
        s,b=post(owner,'admin_photos','photo_edit',edit);check(s==200,'幹事が投稿のタイトル・コメント・表示順を編集')
        s,b=request(participant,'gallery&album='+str(submissionalbum));check('修正したコメント'.encode() in b and b'alert(1)' not in b,'幹事の修正をアルバムに反映')
        s,b=post(owner,'admin_photos','photo_remove',{'id':pfid,'reason':'掲載取下げ試験'});check(s==200,'幹事が写真を削除・履歴保持')
        s,b=request(participant,'file&id='+str(pfid));check(s==403,'削除後の写真は直接URLでも取得不可')
        s,b=request(owner,'file&id='+str(pfid));check(s==403,'削除後は幹事の直接画像取得も不可')
        s,b=post(owner,'admin_photos','photo_restore',{'id':pfid,'reason':'復元試験'});check(s==200 and con.execute('select published from private_files where id=?',(pfid,)).fetchone()[0]==0,'誤削除は非公開で復元・自動再掲載なし')
        s,b=request(participant,'file&id='+str(pfid));check(s==403,'非公開復元後も参加者へ配信しない')
        signup=client();values={'class':1,'name':'見本 太郎','kana':'ミホン タロウ','address':'架空市','phone':'000-0000','email':'kana-form@example.test','email_confirm':'kana-form@example.test','password':'111111','password_confirm':'111111','payer':'やまだ　ﾀﾛｳ','display':'','public':'yes'}
        s,b=post(signup,'register','register',values);check(s==200,'表示名未指定・ひらがな半角名義で架空申込')
        uid=con.execute("select id from users where email='kana-form@example.test'").fetchone()[0]
        import json
        stored=json.loads(con.execute('select data_json from registrations where user_id=?',(uid,)).fetchone()[0]);check(stored['class']==1 and con.execute('select class_no from registrations where user_id=?',(uid,)).fetchone()[0]==1 and stored['display']=='見本 太郎' and stored['payer']=='ヤマダ タロウ','サーバーでも表示名を補完・名義を統一して保存')
        s,b=post(signup,'edit','edit',{**values,'class':'10','name':'見本 次郎','display':'卒業時の見本名','payer':'ﾐﾎﾝ ｼﾞﾛｳ'});stored=json.loads(con.execute('select data_json from registrations where user_id=?',(uid,)).fetchone()[0]);check(s==200 and stored['class']==10 and con.execute('select class_no from registrations where user_id=?',(uid,)).fetchone()[0]==10 and stored['display']=='卒業時の見本名' and stored['payer']=='ミホン ジロウ','表示名の手動変更を保持して保存')
        s,b=post(signup,'edit','edit',{**values,'payer':'山田 太郎'});check(s==400,'直接POSTした漢字名義も拒否')
        s,b=request(anon,'register');check('メールアドレスとパスワードで'.encode() in b and '全員へのお知らせ'.encode() in b,'申込画面にログインと一斉連絡先の案内')
        albumclient=client();s,b=request(albumclient,'gallery&album=1');check(s==200 and b'name="next" value="gallery"' in b,'アルバムからログインすると行先を保持')
        s,b=post(albumclient,'gallery&album=1','login',{'email':'sample3@example.test','password':'wrong','next':'gallery','album':1});check(s==400 and b'name="next" value="gallery"' in b,'失敗後もアルバムへの行先を保持')
        s,b=post(albumclient,'gallery&album=1','login',{'email':'sample3@example.test','password':'111111','next':'gallery','album':1});check(s==200 and 'みんなの写真を、ここに。'.encode() in b,'アルバムからログイン成功後にアルバムを表示')
        safeclient=client();s,b=post(safeclient,'login','login',{'email':'sample3@example.test','password':'111111','next':'https://evil.example/'});check(s==200 and '申込番号'.encode() in b,'不正なログイン後URLを許可せず本人ページへ')
        s,b=request(participant,'admin_broadcast');check(s==403,'参加者に一斉メール画面を公開しない')
        s,b=post(owner,'admin_broadcast','broadcast_preview',{'subject':'開催変更の見本 <script>','body':'架空の一斉連絡です。','target':'all'});check(s==200 and b'&lt;script&gt;' in b and '内容と対象人数を確認'.encode() in b,'幹事が一斉メールの本文と対象を確認・XSS無害化')
        bid=con.execute('select max(id) from broadcasts').fetchone()[0]
        expected=con.execute('select count(*) from registrations').fetchone()[0]
        s,b=post(owner,'admin_broadcast&id='+str(bid),'broadcast_queue',{'id':bid,'confirm':'yes'});check(s==200 and con.execute("select count(*) from broadcast_messages where broadcast_id=? and status='development'",(bid,)).fetchone()[0]==expected,'全申込者へ宛先別に開発メールを登録・実送信なし')
        post(owner,'admin_broadcast&id='+str(bid),'broadcast_queue',{'id':bid,'confirm':'yes'});check(con.execute('select count(*) from broadcast_messages where broadcast_id=?',(bid,)).fetchone()[0]==expected,'同じ一斉メールを再登録しても重複しない')
        s,b=request(owner,'admin_mail');check('開催変更の見本'.encode() in b,'開発メール画面から一斉メール履歴を確認')
        s,b=post(owner,'admin_broadcast&id='+str(bid),'broadcast_cancel',{'id':bid,'reason':'見本停止'});check(s==200 and con.execute("select count(*) from broadcast_messages where broadcast_id=? and status='cancelled'",(bid,)).fetchone()[0]==expected,'一斉メール停止と宛先別状態を保存')
        dry=subprocess.run([php,str(root/'scripts/mail_queue.php')],env=env,capture_output=True);check(dry.returncode==0 and '実送信なし'.encode() in dry.stdout,'メール処理は指定なしでは表示だけ')
        refused=subprocess.run([php,str(root/'scripts/mail_queue.php'),'--send'],env=env,capture_output=True);check(refused.returncode!=0,'開発設定では送信指定も拒否')
        s,b=request(participant,'home');check(b'href="?page=register"' not in b and '申込内容を確認'.encode() in b,'ログイン中は新規申込リンクを非表示・確認へ切替')
        s,b=request(participant,'register');check(s==200 and '申込番号'.encode() in b and b'name="action" value="register"' not in b,'ログイン中の申込URLは本人の申込確認へ')
        count=con.execute('select count(*) from users').fetchone()[0]
        s,b=request(participant,'register',{'csrf':token(participant,'my'),'action':'register',**values,'email':'blocked@example.test','email_confirm':'blocked@example.test'});check(s==400 and con.execute('select count(*) from users').fetchone()[0]==count,'ログイン中の直接POSTによる新規申込も拒否')
        bank={'bankName':'見本銀行（架空） <script>','branchName':'見本支店','accountType':'普通','accountNumber':'００１２３４５','accountHolder':'ミホンドウソウカイ','reason':'架空口座の設定'}
        s,b=post(organizer,'admin_settings','bank_account',bank);check(s==400,'幹事の口座変更POSTを拒否')
        s,b=post(owner,'admin_settings','bank_account',bank);check(s==200 and json.loads(con.execute('select data_json from settings').fetchone()[0])['bankAccount']['accountNumber']=='0012345','管理者が口座設定・先頭ゼロを保持して保存')
        s,b=request(client(),'register');check('0012345'.encode() in b and b'&lt;script&gt;' in b,'未ログインの申込案内に口座情報・XSSを無害化')
        s,b=request(participant,'my');check('0012345'.encode() in b,'申込確認にも振込先口座を表示')
        s,b=request(organizer,'admin_settings');check(b'name="bankName"' not in b and '幹事は閲覧のみ'.encode() in b,'幹事には口座の編集欄を表示しない')
        saved=json.loads(con.execute('select data_json from settings').fetchone()[0]);general={k:str(saved[k]) for k in ['dateLabel','venue','fee','classSize','capacity','opening','open','registration','payment','change','cancel','photoEnd']};general.update(reason='一般設定変更',bankAccount='forged',bankName='forged')
        s,b=post(organizer,'admin_settings','settings',general);check(s==200 and json.loads(con.execute('select data_json from settings').fetchone()[0])['bankAccount']['bankName']==bank['bankName'],'一般設定から口座設定を上書きできない')
        s,b=post(owner,'admin_settings','bank_account',{'reason':'架空口座を取り下げ'});check(s==200 and not json.loads(con.execute('select data_json from settings').fetchone()[0])['bankAccount'],'口座情報を未設定へ戻せる')
        # Admin navigation is contained in admin pages; gallery uses covers and a viewer.
        s,b=request(owner,'home');check(b'class="admin-tabs"' not in b and '幹事画面'.encode() in b,'通常ページは通常メニューだけを常時表示')
        s,b=request(owner,'admin');check(b'class="admin-tabs"' in b,'管理メニューは幹事画面内で表示')
        count_before=con.execute('select count(*) from private_files where submitted=1').fetchone()[0]
        wide=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',2400,4,8,2,0,0,0))+chunk(b'IDAT',zlib.compress((b'\x00'+b'\x99\xdd\xbb'*2400)*4))+chunk(b'IEND',b'')
        batch_ids=[]
        for key in ['a'*32,'b'*32]:
            s,b=post(participant,'my','post_photo',{**postdata,'post_key':key,'title':'複数投稿の見本'}, {'photo':('wide.png','image/png',wide)},True)
            response=json.loads(b);assert s==200 and response['ok'];batch_ids.append(response['id'])
        check(con.execute('select count(*) from private_files where submitted=1').fetchone()[0]==count_before+2,'複数枚投稿用のJSON応答で2枚を連続保存')
        s,b=post(participant,'my','post_photo',{**postdata,'post_key':'a'*32},{'photo':('wide.png','image/png',wide)},True)
        check(json.loads(b)['id']==batch_ids[0] and con.execute('select count(*) from private_files where submitted=1').fetchone()[0]==count_before+2,'再試行でも成功済みの写真を重複しない')
        key=con.execute('select storage_key from private_files where id=?',(batch_ids[0],)).fetchone()[0]
        width=subprocess.check_output([php,'-r','echo getimagesize($argv[1])[0];',tmp+'/private/'+key]).decode()
        check(width=='2000','サーバーでも長辺2000pxへ縮小保存')
        s,b=request(participant,'gallery');check(b'class="album-cover"' in b and '2枚'.encode() in b,'アルバム一覧に表紙と閲覧可能な写真の枚数')
        s,b=request(participant,'gallery&album='+str(submissionalbum));check(b'data-photo-view' in b and b'data-photo-group' in b and b'album-ui.js' in b,'アルバム内の写真を拡大ビューアへ接続')
        s,b=request(participant,'my',{'csrf':'forged','action':'post_photo',**postdata},{'photo':('sample.png','image/png',png)},True)
        check(s==400 and json.loads(b)['ok'] is False,'複数投稿用JSONでもCSRF不一致を拒否')
        # Participant language and next step; use only the isolated test database.
        s,b=request(participant,'my');check('確認済みの入金額'.encode() in b and '申込受付済み'.encode() in b and '会費のお振り込みをお願いします'.encode() in b and '入金割当'.encode() not in b and '未入金・過払い差額'.encode() not in b,'未入金の本人画面に次のお手続きと分かりやすい金額表示')
        # Unknown class registration, combined admin filters, audited staff correction.
        fresh=client();s,b=request(fresh,'register')
        check('value="" disabled selected>クラスを選択'.encode() in b,'申込クラスは未選択の初期表示')
        unknown={'class':'','name':'クラス確認見本','kana':'カクニン ミホン','oldname':'旧姓確認','address':'架空住所','phone':'000-0000-0000','payer':'カクニン ミホン','public':'yes','email':'unknown-class@example.test','email_confirm':'unknown-class@example.test','password':'111111','password_confirm':'111111'}
        s,b=post(fresh,'register','register',unknown);check(s==400,'空欄をクラス不明として勝手に保存しない')
        s,b=post(fresh,'register','register',{**unknown,'class':'0'});check(s==200 and 'クラス確認中'.encode() in b and '3年0組'.encode() not in b,'クラスを忘れたで申込・本人確認が可能')
        up=con.execute("select r.id,r.revision,r.amount,r.user_id from registrations r join users u on u.id=r.user_id where u.email='unknown-class@example.test'").fetchone();uid,rev,amount,user_id=up
        s,b=request(owner,'admin&class_filter=0&query='+urllib.parse.quote('旧姓確認'))
        check(s==200 and 'クラス確認見本'.encode() in b and '表示：1件'.encode() in b,'旧姓検索とクラス未確認を組み合わせて抽出')
        s,b=request(owner,'admin&class_filter=0&payment_filter=unpaid&status_filter=active');check('クラス確認見本'.encode() in b,'クラス・未入金・参加予定の複合絞り込み')
        s,b=request(owner,'admin&query='+urllib.parse.quote('<script>no-match'))
        check(s==200 and '条件に一致する申込はありません'.encode() in b and b'<script>no-match' not in b,'検索0件案内と検索文字のエスケープ')
        correction={'id':uid,'revision':rev,'class':'5','reason':'幹事が本人に確認した見本'}
        s,b=post(fresh,'my','correct_class',correction);check(s==400,'参加者による幹事クラス訂正を拒否')
        s,b=post(owner,'admin','correct_class',{**correction,'reason':''});check(s==400,'クラス訂正の理由は必須')
        s,b=post(owner,'admin','correct_class',{**correction,'revision':rev-1});check(s==400,'古い画面からのクラス訂正を拒否')
        s,b=post(organizer,'admin','correct_class',correction);check(s==200,'幹事が確認済みクラスへ修正')
        stored=con.execute('select class_no,data_json,revision,amount from registrations where id=?',(uid,)).fetchone()
        check(stored[0]==5 and json.loads(stored[1])['class']==5 and stored[2]==rev+1 and stored[3]==amount,'クラスと保存データを一致させ請求額を維持')
        log=con.execute("select before_json,after_json,reason from audit_logs where action='卒業時クラス訂正' and entity=?",('registration:'+str(uid),)).fetchone()
        check(json.loads(log[0])['class']==0 and json.loads(log[1])['class']==5 and log[2]==correction['reason'],'クラス訂正の変更前後・理由を監査ログに保存')
        s,b=request(fresh,'my');check('3年5組'.encode() in b and 'クラス確認中'.encode() not in b,'修正結果を本人画面へ反映')
        s,b=request(owner,'admin&class_filter=0');check('クラス確認見本'.encode() not in b,'修正後はクラス未確認の一覧から除外')
        s,b=request(fresh,'my')
        check(b.count('>申込期限</dt>'.encode())==1 and b.count('>入金期限（振込期限）</dt>'.encode())==1 and b.count('>内容変更期限</dt>'.encode())==1 and b.count('>キャンセル期限</dt>'.encode())==1,'未入金の本人画面は振込先と各期限を一か所で表示')
        payment_csv=f'管理情報\n日付,摘要,摘要内容,支払い金額,預かり金額,差引残高,メモ,未資金化区分,入払区分\n20261031,振込,支払表示テスト,,{amount},500000,,0,入金\n'.encode()
        s,b=post(owner,'admin_bank','import',{}, {'csv':('paid-view.csv','text/csv',payment_csv)});assert s==200
        tid=con.execute('select max(id) from bank_transactions').fetchone()[0]
        s,b=post(owner,'admin_bank','bank_decide',{'id':tid,'state':'confirmed','reason':'画面確認用の見本入金'});assert s==200
        s,b=post(owner,'admin_bank','allocate',{'bank_id':tid,'registration_id':uid,'amount':amount,'reason':'見本の会費入金を確認'});assert s==200
        s,b=request(fresh,'my');check('入金確認済み'.encode() in b and '会費の振込先'.encode() not in b and '入金期限（振込期限）'.encode() not in b and '>申込期限</dt>'.encode() not in b,'入金済みは振込先・入金期限・申込期限を表示しない')
        check(b.count('>内容変更期限</dt>'.encode())==1 and b.count('>キャンセル期限</dt>'.encode())==1,'入金済みは変更・キャンセル期限を各一回表示')
        srv.terminate();srv.wait();srv=subprocess.Popen([php,'-d','session.upload_progress.enabled=0','-S','127.0.0.1:8791','-t',str(root/'public'),str(root/'public/router.php')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        time.sleep(.3);s,b=request(login(1),'admin_accounting');check(s==200 and '架空店'.encode() in b,'再起動後も経費とDBが残る')
        # Expired operations should explain the next step, while server checks remain enforced.
        saved_settings=json.loads(con.execute('SELECT data_json FROM settings WHERE id=1').fetchone()[0])
        expired={**saved_settings,'change':'2000-01-01','cancel':'2000-01-01'}
        con.execute('UPDATE settings SET data_json=? WHERE id=1',(json.dumps(expired),));con.commit()
        s,b=request(fresh,'my')
        check(s==200 and b'href="?page=edit"' not in b and b'name="action" value="cancel"' not in b and '内容変更の受付期限を過ぎています'.encode() in b and 'キャンセルの受付期限を過ぎています'.encode() in b and b'?page=home#contact' in b,'期限後は操作ボタンの代わりに幹事への相談を案内')
        s,b=post(fresh,'my','cancel',{'reason':'期限後の直接送信テスト'})
        check(s==400,'期限後は画面外からの欠席申請も拒否')
        con.execute('UPDATE settings SET data_json=? WHERE id=1',(json.dumps(saved_settings),));con.commit()
        s,b=request(fresh,'my')
        check(b'href="?page=edit"' in b and b'name="action" value="cancel"' in b,'期限内は変更・欠席申請の操作を表示')
        no_address=client()
        s,b=post(no_address,'register','register',{**unknown,'class':'1','email':'optional-address@example.test','email_confirm':'optional-address@example.test','postal':'','address':'','phone':'09012345678'})
        check(s==200 and '申込受付済み'.encode() in b,'住所・郵便番号なしでも新規申込が可能')
        optional=con.execute("select r.data_json from registrations r join users u on u.id=r.user_id where u.email='optional-address@example.test'").fetchone()
        check(json.loads(optional[0])['address']=='' and json.loads(optional[0])['postal']=='' and json.loads(optional[0])['phone']=='09012345678','住所の空欄とハイフンなし電話番号を保存')
        short_password=client()
        short_data={**unknown,'class':'1','email':'three-character@example.test','email_confirm':'three-character@example.test','password':'12','password_confirm':'12'}
        s,b=post(short_password,'register','register',short_data)
        check(s==400 and '3桁以上のパスワードを設定してください'.encode() in b,'2文字のパスワードは指定の案内で拒否')
        s,b=post(short_password,'register','register',{**short_data,'password':'123','password_confirm':'123'})
        check(s==200 and '申込受付済み'.encode() in b,'3文字のパスワードで参加申込を保存')
        short_login=client();s,b=post(short_login,'login','login',{'email':'three-character@example.test','password':'123'})
        check(s==200 and 'クラス確認見本'.encode() in b,'3文字で設定したパスワードで本人ログイン')
        # Attendance recovery and refund ledger use the same registration and shared bank remainder.
        target=con.execute("select r.id,r.amount,r.user_id from registrations r join users u on u.id=r.user_id where u.email='three-character@example.test'").fetchone()
        target_id,target_amount,target_user=target
        s,b=post(short_password,'my','cancel',{'reason':'再参加試験のため欠席申請'});check(s==200 and b'name="action" value="withdraw_cancel"' in b,'欠席申請後に本人の取り消しフォームを表示')
        rev=con.execute('select revision from registrations where id=?',(target_id,)).fetchone()[0]
        s,b=post(short_password,'my','withdraw_cancel',{'revision':rev-1,'reason':'古い画面'});check(s==400,'古い版の欠席取り消しをHTTPで拒否')
        s,b=post(short_password,'my','withdraw_cancel',{'revision':rev,'reason':'都合がついた'});check(s==200 and con.execute('select status from registrations where id=?',(target_id,)).fetchone()[0]=='active','本人が欠席申請を取り消して参加予定へ戻せる')
        s,b=post(short_password,'my','cancel',{'reason':'返金試験のため欠席'});assert s==200
        s,b=post(owner,'admin_refunds','cancel_decide',{'id':target_id,'decision':'approve','reason':'欠席確定'});check(s==200,'幹事が欠席を確定')
        # Allocate a transfer received before cancellation; the database fixture is active only for the allocation.
        con.execute("update registrations set status='active' where id=?",(target_id,));con.commit()
        bank_date=datetime.date.today().strftime('%Y%m%d')
        refund_csv=f'日付,摘要,摘要内容,支払い金額,預かり金額,差引残高,メモ,未資金化区分,入払区分\n{bank_date},振込,再参加テスト,,{target_amount},900000,,0,入金\n{bank_date},出金,返金テスト,{target_amount},,891000,,0,出金\n'.encode()
        s,b=post(owner,'admin_bank','import',{}, {'csv':('refund-fixture.csv','text/csv',refund_csv)});assert s==200
        bank_in,bank_out=[r[0] for r in con.execute('select id from bank_transactions order by id desc limit 2').fetchall()[::-1]]
        for bid in (bank_in,bank_out):
            s,b=post(owner,'admin_bank','bank_decide',{'id':bid,'state':'confirmed','reason':'架空明細確認'});assert s==200
        s,b=post(owner,'admin_bank','allocate',{'bank_id':bank_in,'registration_id':target_id,'amount':target_amount,'reason':'取消前の入金'});assert s==200
        con.execute("update registrations set status='cancelled' where id=?",(target_id,));con.commit()
        s,b=request(short_password,'admin_refunds');check(s==403,'参加者から返金管理の閲覧を拒否')
        plan={'registration_id':target_id,'amount':target_amount,'request_key':'7'*32,'reason':'全額返金の見本'}
        s,b=post(short_password,'my','refund_plan',plan);check(s==400,'参加者の返金予定登録を拒否')
        s,b=post(owner,'admin_refunds','refund_plan',plan);check(s==200,'幹事が返金予定を登録')
        refund_id=con.execute('select max(id) from refunds').fetchone()[0]
        s,b=post(owner,'admin_refunds','refund_plan',plan);check(s==200 and con.execute('select count(*) from refunds').fetchone()[0]==1,'返金予定の二重送信を重複保存しない')
        s,b=post(owner,'admin_refunds','refund_plan',{**plan,'request_key':'8'*32,'amount':1});check(s==400,'予定済み返金を超える登録を拒否')
        rev=con.execute('select revision from registrations where id=?',(target_id,)).fetchone()[0]
        s,b=post(short_password,'my','request_rejoin',{'revision':rev,'reason':'再参加を希望'});check(s==200 and '再参加申請受付済み'.encode() in b,'本人から再参加を申請')
        s,b=post(owner,'admin_refunds','rejoin_decide',{'id':target_id,'decision':'approve','reason':'未送金の予定が残る'});check(s==400,'未送金返金を残した再参加承認を拒否')
        s,b=post(owner,'admin_refunds','rejoin_decide',{'id':target_id,'decision':'reject','reason':'返金後に再確認'});assert s==200
        s,b=post(owner,'admin_refunds','refund_record',{'id':refund_id,'date':str(datetime.date.today()),'reference':'架空送金番号','reason':'銀行側で実施した内容の記録'});check(s==200,'送金済み内容を記録（実送金なし）')
        s,b=request(short_password,'my');check('返金記録合計'.encode() in b and '銀行照合待ち'.encode() in b,'本人画面に返金記録と銀行照合待ちを表示')
        s,b=post(owner,'admin_refunds','refund_link',{'id':refund_id,'bank_id':bank_out,'amount':target_amount,'reason':'出金と返金が一致'});check(s==200,'返金記録と銀行出金を照合')
        s,b=post(owner,'admin_refunds','refund_link',{'id':refund_id,'bank_id':bank_out,'amount':1,'reason':'二重'});check(s==400,'返金の二重割当をHTTPで拒否')
        s,b=post(owner,'admin_bank','allocate',{'bank_id':bank_out,'expense_id':eid,'amount':1,'reason':'同じ銀行出金を経費に割当'});check(s==400,'返金済み出金の経費への重複割当を拒否')
        s,b=post(owner,'admin_refunds','refund_undo',{'id':refund_id,'reason':'照合中の訂正'});check(s==400,'出金照合中の返金記録訂正を拒否')
        rev=con.execute('select revision from registrations where id=?',(target_id,)).fetchone()[0]
        s,b=post(short_password,'my','request_rejoin',{'revision':rev,'reason':'改めて再参加'});assert s==200
        s,b=post(owner,'admin_refunds','rejoin_decide',{'id':target_id,'decision':'approve','reason':'定員と返金記録を確認'});check(s==200,'幹事が再参加を承認')
        s,b=request(short_password,'my');check('返金差引後の入金額'.encode() in b and '会費のお振り込みをお願いします'.encode() in b and '会費の振込先'.encode() in b,'再参加時は返金を差し引いて追加の会費を案内')
        check(con.execute('select id,amount from registrations where user_id=?',(target_user,)).fetchone()==(target_id,target_amount),'再参加しても申込番号と当初会費を維持')
        s,b=request(owner,'export&kind=refunds');check(s==200 and '架空送金番号'.encode() in b,'返金一覧CSVを出力')
        income_allocation=con.execute('select id from allocations where bank_id=?',(bank_in,)).fetchone()[0]
        s,b=post(owner,'admin_bank','reverse',{'id':income_allocation,'reason':'返金の根拠入金を消す'});check(s==400,'返金の根拠入金の取消を拒否')
        link_id=con.execute('select max(id) from refund_links').fetchone()[0]
        s,b=post(owner,'admin_refunds','refund_unlink',{'id':link_id,'reason':'照合訂正'});check(s==200,'返金の銀行照合を理由付きで取消')
        s,b=post(owner,'admin_refunds','refund_undo',{'id':refund_id,'reason':'誤記を訂正'});check(s==200,'照合を外して返金記録を訂正')
        s,b=post(owner,'admin_refunds','refund_cancel',{'id':refund_id,'reason':'誤った予定を取消'});check(s==200,'返金予定を履歴付きで取消')
        check(con.execute('select count(*) from audit_logs where action like ?',('%返金%',)).fetchone()[0]>=6,'返金と訂正の履歴を保存')
        # Team assignments are distinct from login permissions; external helpers have no account.
        s,b=request(organizer,'admin_contacts');check(s==200 and '担当・役割管理'.encode() in b,'幹事が担当一覧を閲覧')
        s,b=request(participant,'admin_contacts');check(s==403,'参加者の担当一覧を拒否')
        duty={'roleKey':'accounting','kind':'member','userId':3,'class':'0','status':'active','scope':'架空の会費管理','description':'照合と報告','note':'幹事内限定メモ','reason':'架空の担当を設定'}
        s,b=post(organizer,'admin_contacts','duty_save',duty);check(s==400,'幹事の担当設定を拒否')
        s,b=post(owner,'admin_contacts','duty_save',duty);check(s==200 and '架空の会費管理'.encode() in b,'管理者が担当を設定')
        duty_id=con.execute('select max(id) from duties').fetchone()[0]
        check(con.execute('select role from users where id=3').fetchone()[0]=='participant','担当登録で権限を付与しない')
        s,b=request(participant,'my');check('あなたの担当'.encode() in b and '会計担当'.encode() in b and '幹事内限定メモ'.encode() not in b,'本人の担当表示から内部メモを除外')
        s,b=request(organizer,'admin_contacts&role=accounting');check('架空の会費管理'.encode() in b,'役割で検索')
        s,b=request(owner,'admin_contacts&mine=yes');check('架空の会費管理'.encode() not in b,'自分の担当だけを表示')
        users_before=con.execute('select count(*) from users').fetchone()[0]
        s,b=post(owner,'admin_contacts','duty_save',{**duty,'roleKey':'mc','kind':'external','externalName':'架空の司会者','contact':'架空の連絡メモ'});check(s==200 and '架空の司会者'.encode() in b,'外部の司会者を登録')
        check(con.execute('select count(*) from users').fetchone()[0]==users_before,'外部協力者のアカウントを作成しない')
        external_id=con.execute('select max(id) from duties').fetchone()[0]
        s,b=request(organizer,'admin_contacts&detail='+str(external_id));check('架空の連絡メモ'.encode() in b,'幹事が外部連絡メモを詳細で確認')
        s,b=request(organizer,'export&kind=duties&dutyKind=external');check(s==200 and '架空の司会者'.encode() in b and '会計担当'.encode() not in b,'絞り込んだ担当一覧CSV')
        s,b=post(owner,'admin_contacts','duty_save',{**duty,'id':duty_id,'revision':0});check(s==400,'古い担当編集を拒否')
        s,b=post(owner,'admin_contacts','duty_save',{**duty,'id':duty_id,'revision':1,'status':'inactive'});check(s==200,'担当を履歴付きで解除')
        s,b=request(participant,'my');check('架空の会費管理'.encode() not in b,'担当解除が本人画面へ反映')
        s,b=request(owner,'admin_contacts&mode=classes&class=1');check(s==200 and 'クラス幹事を追加'.encode() in b,'従来のクラス幹事設定を保持')
        print('ALL',n,'HTTP CHECKS PASSED')
    finally:srv.terminate();srv.wait()
