<?php
declare(strict_types=1);
require __DIR__.'/../src/bootstrap.php';require APP_ROOT.'/src/domain.php';require APP_ROOT.'/src/community.php';require __DIR__.'/demo_roster.php';
$cmd=$argv[1]??'help';
if(in_array($cmd,['init','migrate'],true)){schema();echo "スキーマ初期化完了\n";}
elseif($cmd==='seed'){requirev($config['mode']==='development','開発環境専用です。');schema();requirev(!one('SELECT id FROM users'),'空のDBでのみ実行できます。');$hash=password_hash('111111',PASSWORD_DEFAULT);atomic(function()use($hash){for($i=1;$i<=160;$i++)demoInsert($i,($i-1)%10+1,intdiv($i-1,10),$hash);foreach([3,6,9] as $j=>$cl)demoInsert(161+$j,$cl,16,$hash,'cancelled');});echo "架空163件、参加予定160人（各組16人）、取消3件。sample1=代表、sample2=幹事、sample3=参加者。@example.test / 111111\n";}
elseif($cmd==='expand-demo-roster'){expandDemoRoster();}
elseif($cmd==='seed-community'){
 requirev($config['mode']==='development','開発環境専用です。');schema();
 foreach(all('SELECT email FROM users') as $u)requirev(str_ends_with($u['email'],'@example.test'),'見本アカウントだけのDBで実行してください。');
 $owner=one("SELECT id,email,role,name FROM users WHERE role='owner' ORDER BY id LIMIT 1");requirev((bool)$owner,'先にseedしてください。');
 atomic(function()use($owner){for($cl=1;$cl<=10;$cl++){if(classContacts($cl))continue;foreach(array_slice(all("SELECT user_id FROM registrations WHERE class_no=? AND status='active' ORDER BY id",[$cl]),0,2) as $j=>$p)setClassContact($owner,['class'=>$cl,'user_id'=>$p['user_id'],'position'=>$j+1,'reason'=>'架空のクラス幹事表示見本']);}});echo "架空のクラス幹事を各組2名設定しました。管理権限は変更していません。\n";
}
elseif($cmd==='owner'){schema();$email=$argv[2]??'';requirev(filter_var($email,FILTER_VALIDATE_EMAIL)!==false,'メールアドレスを指定してください。');fwrite(STDOUT,"代表幹事パスワードを標準入力から入力（チャットやコマンド引数に記載しない）: ");$pw=trim(fgets(STDIN));passwordv($pw);atomic(function()use($email,$pw){global $db;requirev(!one('SELECT id FROM users WHERE email=?',[$email]),'登録済みです。');q('INSERT INTO users (email,password_hash,role,name,created) VALUES (?,?,?,?,?)',[$email,password_hash($pw,PASSWORD_DEFAULT),'owner','代表幹事',nowv()]);logv((int)$db->lastInsertId(),'代表幹事初期登録','setup',null,null,'CLI初期化');});echo "登録完了\n";}
else echo "php scripts/manage.php init | seed | owner メールアドレス\n";
